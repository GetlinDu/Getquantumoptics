# -*- coding: UTF-8 -*-
'''
@Author  ：程序员晚枫，B站/抖音/微博/小红书/公众号
@WeChat     ：CoderWanFeng
@Blog      ：www.python-office.com
@Date    ：2023/1/4 14:42 
@Description     ：
'''

from setuptools import setup  # 这个包没有的可以pip一下

setup()